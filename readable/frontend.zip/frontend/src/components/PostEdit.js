import React, { Component } from 'react'
import { connect } from 'react-redux'
import {
  Button,
  Col,
  Row,

} from 'react-bootstrap'
import { fetchPostById } from '../assets/flow/actions';


class PostEdit extends Component {

    componentDidMount() {
        const { dispatch ,location} = this.props
       
        dispatch(fetchPostById(location.state.post_id))
    }
    
    render() {
        return(
            <div className="posts">
            
            <Row>
              <Col md={12}>
                
                <form className='create-comment-form' onSubmit={this.onSubmitHandler}>
                    <input onChange={this.handleInputChange} type='text' placeholder='Title' name='title'></input>
                    <input onChange={this.handleInputChange} type='text' placeholder='Text' name='text'></input>
                    <Button bsSize="lg">Send</Button>
                </form>

             
              </Col>
            </Row>
            
            </div>
        )

    }
}

const mapStateToProps = ({posts}) => ({posts})
export default connect(mapStateToProps)(PostEdit)


